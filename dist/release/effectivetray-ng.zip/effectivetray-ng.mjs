// <copyright file="const.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>

const MODULE = "effectivetray-ng";
const SOCKET_ID = "module.effectivetray-ng";

// <copyright file="settings.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>


class ModuleSettings {

  static init() {
    ModuleSettings._chatSettings();
  }

  static _chatSettings() {
    game.settings.register(MODULE, "allowTarget", {
      name: "EFFECTIVETRAY.AllowTargetSettingName",
      hint: "EFFECTIVETRAY.AllowTargetSettingHint",
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      requiresReload: true,
      onChange: false
    });

    game.settings.register(MODULE, "damageTarget", {
      name: "EFFECTIVETRAY.DamageTargetSettingName",
      hint: "EFFECTIVETRAY.DamageTargetSettingHint",
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      requiresReload: true,
      onChange: false
    });

    game.settings.register(MODULE, "deleteInstead", {
      name: "EFFECTIVETRAY.DeleteInsteadSettingName",
      hint: "EFFECTIVETRAY.DeleteInsteadSettingHint",
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      requiresReload: false,
      onChange: false
    });

    game.settings.register(MODULE, "ignoreNPC", {
      name: "EFFECTIVETRAY.IgnoreNPCSettingName",
      hint: "EFFECTIVETRAY.IgnoreNPCSettingHint",
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      requiresReload: true,
      onChange: false
    });

    game.settings.register(MODULE, "filterPermission", {
      name: "EFFECTIVETRAY.FilterPermissionSettingName",
      hint: "EFFECTIVETRAY.FilterPermissionSettingHint",
      scope: "world",
      config: true,
      type: Number,
      default: 0,
      requiresReload: true,
      choices: {
        0: "EFFECTIVETRAY.NoFilter",
        1: "OWNERSHIP.LIMITED",
        2: "OWNERSHIP.OBSERVER",
        3: "OWNERSHIP.OWNER",
        4: "EFFECTIVETRAY.GmOnly"
      }
    });

    game.settings.register(MODULE, "filterDisposition", {
      name: "EFFECTIVETRAY.FilterDispositionSettingName",
      hint: "EFFECTIVETRAY.FilterDispositionSettingHint",
      scope: "world",
      config: true,
      type: Number,
      default: 0,
      requiresReload: true,
      choices: {
        0: "EFFECTIVETRAY.NoFilter",
        1: "TOKEN.DISPOSITION.SECRET",
        2: "TOKEN.DISPOSITION.HOSTILE",
        3: "TOKEN.DISPOSITION.NEUTRAL"
      }
    });

    game.settings.register(MODULE, "multipleConcentrationEffects", {
      name: "EFFECTIVETRAY.MultipleConcentrationEffectsSettingName",
      hint: "EFFECTIVETRAY.MultipleConcentrationEffectsSettingHint",
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      requiresReload: false,
      onChange: false
    });

    game.settings.register(MODULE, "systemDefault", {
      name: "EFFECTIVETRAY.SystemDefaultSettingName",
      hint: "EFFECTIVETRAY.SystemDefaultSettingHint",
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      requiresReload: true,
      onChange: false
    });

    game.settings.register(MODULE, "damageDefault", {
      name: "EFFECTIVETRAY.DamageDefaultSettingName",
      hint: "EFFECTIVETRAY.DamageDefaultSettingHint",
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      requiresReload: true,
      onChange: false
    });
  }
}

// <copyright file="damage-application.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>


/* -------------------------------------------- */
/*  Damage Application Extension (from dnd5e)   */
/*  Refer to dnd5e for full documentation       */
/* -------------------------------------------- */

const MULTIPLIERS = [[-1, "-1"], [0, "0"], [.25, "¼"], [.5, "½"], [1, "1"], [2, "2"]];

class EffectiveDamageApplication {

  static init() {
    /**
     * Add the damage tray for players.
     * @param {ChatMessage5e} message The message on which the tray resides.
     * @param {HTMLElement} html      HTML contents of the message.
     */
    Hooks.on("dnd5e.renderChatMessage", (message, html) => {
      if (!message.isContentVisible || game.user.isGM) return;
      const rolls = message.rolls.filter(r => r instanceof CONFIG.Dice.DamageRoll);
      if (!rolls.length) return;
      const damageApplication = document.createElement("damage-application");
      damageApplication.damages = dnd5e.dice.aggregateDamageRolls(rolls, { respectProperties: true }).map(roll => ({
        value: roll.total,
        type: roll.options.type,
        properties: new Set(roll.options.properties ?? [])
      }));
      html.querySelector(".message-content").appendChild(damageApplication);
    });

    libWrapper.register("effectivetray-ng", "dnd5e.applications.components.DamageApplicationElement.prototype.buildTargetListEntry", function({ uuid, name }) {
      // Override checking isOwner
      const actor = fromUuidSync(uuid);
      if (!game.settings.get(MODULE, "damageTarget") && !actor?.isOwner) return;

      // Calculate damage to apply
      const targetOptions = this.getTargetOptions(uuid);
      const { temp, total, active } = this.calculateDamage(actor, targetOptions);

      const types = [];
      for (const [change, values] of Object.entries(active)) {
        if ( foundry.utils.getType(values) !== "Set" ) continue;
        for (const type of values) {
          const config = CONFIG.DND5E.damageTypes[type] ?? CONFIG.DND5E.healingTypes[type];
          if (!config) continue;
          const data = { type, change, icon: config.icon };
          types.push(data);
        }
      }
      const changeSources = types.reduce((acc, config) => acc + this.getChangeSourceButton(config, targetOptions), "");

      const li = document.createElement("li");
      li.classList.add("target");
      li.dataset.targetUuid = uuid;
      li.innerHTML = `
        <img class="gold-icon">
        <div class="name-stacked">
          <span class="title"></span>
          <span class="subtitle">${changeSources}</span>
        </div>
        <div class="calculated damage">
          ${total}
        </div>
        <div class="calculated temp" data-tooltip="DND5E.HitPointsTemp">
          ${temp}
        </div>
        <menu class="damage-multipliers unlist"></menu>
      `;
      Object.assign(li.querySelector(".gold-icon"), { alt: name, src: actor.img });
      li.querySelector(".name-stacked .title").append(name);

      const menu = li.querySelector("menu");
      for (const [value, display] of MULTIPLIERS) {
        const entry = document.createElement("li");
        entry.innerHTML = `
          <button class="multiplier-button" type="button" value="${value}">
            <span>${display}</span>
          </button>
        `;
        menu.append(entry);
      }

      this.refreshListEntry(actor, li, targetOptions);
      li.addEventListener("click", this._onChangeOptions.bind(this));

      return li;
    }, libWrapper.OVERRIDE);

    libWrapper.register("effectivetray-ng", "dnd5e.applications.components.DamageApplicationElement.prototype.connectedCallback", function(wrapped){
      wrapped();

      // Override to hide target selection if there are no targets
      if (!game.settings.get(MODULE, "damageTarget")) {
        const targets = this.chatMessage.getFlag("dnd5e", "targets");
        const ownership = EffectiveTray.ownershipCheck(targets);
        if (!ownership) this.targetSourceControl.hidden = true;
      }    }, libWrapper.WRAPPER);

    libWrapper.register("effectivetray-ng", "dnd5e.applications.components.DamageApplicationElement.prototype._onApplyDamage", async function(...args) {
      event.preventDefault();
      for ( const target of this.targetList.querySelectorAll("[data-target-uuid]") ) {
        const id = target.dataset.targetUuid;
        const token = fromUuidSync(id);
        const options = this.getTargetOptions(id);
        if (token?.isOwner) {
          await token?.applyDamage(this.damages, { ...options, isDelta: true });
        }
        else {
          // Override to convert damage properties to an Array for socket emission
          if (!game.settings.get(MODULE, 'damageTarget')) return;
          if (!game.users.activeGM) return ui.notifications.warn(game.i18n.localize("EFFECTIVETRAY.NOTIFICATION.NoActiveGMDamage"));
          const damage = [];
          foundry.utils.deepClone(this.damages).forEach(d => {
            foundry.utils.mergeObject(d, { properties: Array.from(d.properties) });
            damage.push(d);
          });
          const opts = foundry.utils.deepClone(options);
          if (opts?.downgrade) foundry.utils.mergeObject(opts, { downgrade: Array.from(opts.downgrade) });
          if (opts?.ignore?.immunity) foundry.utils.mergeObject(opts, { "ignore.immunity": Array.from(opts.ignore.immunity) });
          if (opts?.ignore?.resistance) foundry.utils.mergeObject(opts, { "ignore.resistance": Array.from(opts.ignore.resistance) });
          if (opts?.ignore?.vulnerability) foundry.utils.mergeObject(opts, { "ignore.vulnerability": Array.from(opts.ignore.vulnerability) });
          if (opts?.ignore?.modification) foundry.utils.mergeObject(opts, { "ignore.modification": Array.from(opts.ignore.modification) });
          await game.socket.emit(SOCKET_ID, { type: "damage", data: { id, opts, damage } });
        }
      }
      if ( game.settings.get("dnd5e", "autoCollapseChatTrays") !== "manual" ) {
        this.open = false;
      }
    }, libWrapper.OVERRIDE);
  }
}

// <copyright file="effect-application.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>


/* -------------------------------------------- */
/*  Effect Application Extension (from dnd5e)   */
/*  Refer to dnd5e for full documentation       */
/* -------------------------------------------- */

class EffectiveEffectApplication {
  static init() {
    /**
     * Override the display of the effects tray with effects the user can apply.
     * Refer to dnd5e for full documentation.
     * @param {HTMLLiElement} html  The chat card.
     * @protected
     */
    libWrapper.register("effectivetray-ng", "dnd5e.documents.ChatMessage5e.prototype._enrichUsageEffects", function(html) {
      const item = this.getAssociatedItem();

      // Additional effect detection
      let effects;
      if (this.getFlag("dnd5e", "messageType") === "usage") {
        effects = this?.getFlag("dnd5e", "use.effects")?.map(id => item?.effects.get(id));
      } else {
        if (this.getFlag("dnd5e", "roll.type")) return;
        effects = item?.effects.filter(e => (e.type !== "enchantment") && !e.getFlag("dnd5e", "rider"));
      }
      if (!effects?.length || foundry.utils.isEmpty(effects)) return;
      if (!effects.some(e => e.type !== "enchantment")) return;

      // Handle filtering based on actor
      const actor = this.getAssociatedActor();
      if (game.settings.get(MODULE, "ignoreNPC") && actor?.type === "npc" && !actor?.isOwner) return;
      const filterDis = game.settings.get(MODULE, "filterDisposition");
      if (filterDis) {
        const token = game.scenes?.get(this.speaker?.scene)?.tokens?.get(this.speaker?.token);
        if (token && filterDis === 3 && token.disposition <= CONST.TOKEN_DISPOSITIONS.NEUTRAL && !token?.isOwner) return;
        else if (token && filterDis === 2 && token.disposition <= CONST.TOKEN_DISPOSITIONS.HOSTILE && !token?.isOwner) return;
        else if (token && filterDis === 1 && token.disposition <= CONST.TOKEN_DISPOSITIONS.SECRET && !token?.isOwner) return;
      }
      const filterPer = game.settings.get(MODULE, "filterPermission");
      if (filterPer) {
        if (filterPer === 1 && !actor?.testUserPermission(game.user, CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED)) return;
        else if (filterPer === 2 && !actor?.testUserPermission(game.user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER)) return;
        else if (filterPer === 3 && !actor?.isOwner) return;
        else if (filterPer === 4 && !game.user.isGM) return;
      }

      const effectApplication = document.createElement("effect-application");
      effectApplication.effects = effects;
      return html.querySelector(".message-content").appendChild(effectApplication);
    }, libWrapper.OVERRIDE);

    /**
     * Handle applying an Active Effect to a Token.
     * @param {ActiveEffect5e} effect      The effect to apply.
     * @param {Actor5e} actor              The actor.
     * @returns {Promise<ActiveEffect5e>}  The created effect.
     * @protected
     */
    libWrapper.register("effectivetray-ng", "dnd5e.applications.components.EffectApplicationElement.prototype._applyEffectToActor", function(effect, actor, { effectData, concentration }) {
      const applied = EffectiveTray.applyEffectToActor(effect, actor, { effectData, concentration });
      return applied;
    }, libWrapper.OVERRIDE);

    libWrapper.register("effectivetray-ng", "dnd5e.applications.components.EffectApplicationElement.prototype.buildTargetListEntry", function({ uuid, name}) {
      // Override checking isOwner
      const actor = fromUuidSync(uuid);
      if (!game.settings.get(MODULE, "allowTarget") && !actor?.isOwner) return;

      const disabled = this.targetingMode === "selected" ? " disabled" : "";
      const checked = this.targetChecked(uuid) ? " checked" : "";

      const li = document.createElement("li");
      li.classList.add("target");
      li.dataset.targetUuid = uuid;
      li.innerHTML = `
        <img class="gold-icon">
        <div class="name-stacked">
          <span class="title"></span>
        </div>
        <div class="checkbox">
          <dnd5e-checkbox name="${uuid}"${checked}${disabled}></dnd5e-checkbox>
        </div>
      `;
      Object.assign(li.querySelector(".gold-icon"), { alt: name, src: actor.img });
      li.querySelector(".name-stacked .title").append(name);

      return li;
    }, libWrapper.OVERRIDE);

    libWrapper.register("effectivetray-ng", "dnd5e.applications.components.EffectApplicationElement.prototype.connectedCallback", function(wrapped) {
      wrapped();

      // Override to hide target selection if there are no targets
      if (!game.settings.get(MODULE, "allowTarget") && !game.user.isGM) {
        const targets = this.chatMessage.getFlag("dnd5e", "targets");
        const ownership = EffectiveTray.ownershipCheck(targets);
        if (!ownership) this.targetSourceControl.hidden = true;
      }    }, libWrapper.WRAPPER);

    /**
     * Handle clicking the apply effect button.
     * @param {PointerEvent} event  Triggering click event.
     * @throws {Error}              If the effect could not be applied.
     */
    libWrapper.register("effectivetray-ng", "dnd5e.applications.components.EffectApplicationElement.prototype._onApplyEffect", async function(event) {
      event.preventDefault();
      const effect = this.chatMessage.getAssociatedItem()?.effects.get(event.target.closest("[data-id]")?.dataset.id);
      if (!effect) return;
      const concentration = this.chatMessage.getAssociatedActor()?.effects
        .get(this.chatMessage.getFlag("dnd5e", "use.concentrationId"));
      const origin = concentration ?? effect;

      // Override to accomodate helper params
      const effectData = {
        flags: {
          dnd5e: {
            dependentOn: origin.uuid,
            scaling: this.chatMessage.getFlag("dnd5e", "scaling"),
            spellLevel: this.chatMessage.getFlag("dnd5e", "use.spellLevel")
          }
        }
      };

      const unownedTargets = [];
      for (const target of this.targetList.querySelectorAll("[data-target-uuid]")) {
        const actor = fromUuidSync(target.dataset.targetUuid);
        if (!actor || !target.querySelector("dnd5e-checkbox")?.checked) continue;
        try {
          if (actor.isOwner) {
            this._applyEffectToActor(effect, actor, { effectData, concentration });
          } else {
            if (game.settings.get(MODULE, 'allowTarget')) unownedTargets.push(target.dataset.targetUuid);
          }
        } catch (err) {
          Hooks.onError("EffectiveEffectApplication._applyEffectToToken", err, { notify: "warn", log: "warn" });
        }
      }

      if ( game.settings.get("dnd5e", "autoCollapseChatTrays") !== "manual" ) {
        this.querySelector(".collapsible").dispatchEvent(new PointerEvent("click", { bubbles: true, cancelable: true }));
      }

      // Unowned targets handling
      if (!game.settings.get(MODULE, 'allowTarget')) return;
      if (!game.users.activeGM) return ui.notifications.warn(game.i18n.localize("EFFECTIVETRAY.NOTIFICATION.NoActiveGMEffect"));
      const source = effect.uuid;
      const con = concentration?.id;
      const caster = this.chatMessage.getAssociatedActor().uuid;
      await game.socket.emit(SOCKET_ID, { type: "effect", data: { source, targets: unownedTargets, effectData, con, caster } });
    }, libWrapper.OVERRIDE);
  }
}

// <copyright file="effective-tray.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>


class EffectiveTray {
  static init() {

    // Modify the damage tray
    if (!game.settings.get(MODULE, "damageDefault")) {
      EffectiveDamageApplication.init();
    }

    // Modify the effects tray
    if (!game.settings.get(MODULE, "systemDefault")) {
      EffectiveEffectApplication.init();
    }

    // Add dependent effect to a concentration effect.
    Hooks.on("createActiveEffect", EffectiveTray.#addDependent);

    // Misc
    Hooks.on("preCreateActiveEffect", EffectiveTray._enchantmentSpellLevel);
  }

  /**
   * When an effect is created, if a specific user id and concentration uuid is passed,
   * add the created effect as a dependent on the concentration effect.
   * @param {ActiveEffect5e} effect     The effect that was created.
   * @param {object} operation          The creation context.
   */
  static async #addDependent(effect, operation) {
    const { userId, concentrationUuid } = operation.effectiv ?? {};
    if (game.user.id !== userId) return;
    const concentration = await fromUuid(concentrationUuid);
    if (concentration) concentration.addDependent(effect);
  }

  /**
   * Scroll tray to bottom if at bottom
   * @param {string} mid The message id.
   */
  static async _scroll(mid, delay) {
    if (delay) new Promise(r => setTimeout(r, 10));
    if (mid !== game.messages.contents.at(-1).id) return;
    if (window.ui.chat.isAtBottom) {
      await new Promise(r => setTimeout(r, 256));
      window.ui.chat.scrollBottom({ popout: false });
    }    if (window.ui.sidebar.popouts.chat && window.ui.sidebar.popouts.chat.isAtBottom) {
      await new Promise(r => setTimeout(r, 256));
      window.ui.sidebar.popouts.chat.scrollBottom();
    }  }

  /* -------------------------------------------- */
  /*  Effect Handling                             */
  /* -------------------------------------------- */

  /**
   * Apply effect, or refresh its duration (and level) if it exists
   * @param {Actor5e} actor                          The actor to create the effect on.
   * @param {ActiveEffect5e} effect                  The effect to create.
   * @param {object} [options]                       Additional data that may be included with the effect.
   * @param {object} [options.effectData]            A generic data object that contains spellLevel in a `dnd5e` scoped flag, and whatever else.
   * @param {ActiveEffect5e} [options.concentration] The concentration effect on which `effect` is dependent, if it requires concentration.
   */
  static async applyEffectToActor(effect, actor, { effectData, concentration }) {
    const origin = game.settings.get(MODULE, "multipleConcentrationEffects") ? effect : concentration ?? effect;

    // Enable an existing effect on the target if it originated from this effect
    const existingEffect = game.settings.get(MODULE, "multipleConcentrationEffects") ?
      actor.effects.find(e => e.origin === effect.uuid) :
      actor.effects.find(e => e.origin === origin.uuid);

    if (existingEffect) {
      if (!game.settings.get(MODULE, "deleteInstead")) {
        return existingEffect.update(foundry.utils.mergeObject({
          ...effect.constructor.getInitialDuration(),
          disabled: false
        }, effectData));

        // Or delete it instead
      } else existingEffect.delete();
    } else {

      // Otherwise, create a new effect on the target
      effect instanceof ActiveEffect ? effect = effect.toObject() : effect;
      effectData = foundry.utils.mergeObject({
        ...effect,
        disabled: false,
        transfer: false,
        origin: origin.uuid
      }, effectData);

      // Handle calling the pre hook
      const hookData = EffectiveTray._hookHandler(effectData, actor, concentration);
      if (hookData === false) return;
      effectData = hookData;

      const applied = await ActiveEffect.implementation.create(effectData, { parent: actor });

      // Call the post hook
      Hooks.callAll("effectiv.applyEffect", effectData, actor, concentration);

      return applied;
    }  }

  // Synchronous hook handling
  static _hookHandler(effectData, actor, concentration) {
    const callback = Hooks.call("effectiv.preApplyEffect", effectData, actor, concentration);
    if (callback === false) return false;
    return effectData;
  }

  /* -------------------------------------------- */
  /*  Damage Handling                             */
  /* -------------------------------------------- */

  /**
   * Apply damage
   * @param {string} id       The id of the actor to apply damage to.
   * @param {object} options  The options provided by the tray, primarily the multiplier.
   * @param {Array<Record<string, unknown>|Set<unknown>>} damage An array of objects with the damage type and 
   *                                                             value that also contain Sets with damage properties.
   */
  static async applyTargetDamage(id, options, damage) {
    const actor = fromUuidSync(id);
    await actor.applyDamage(damage, options);
  }

  /* -------------------------------------------- */
  /*  Misc. Methods                               */
  /* -------------------------------------------- */

  /**
   * Before an effect is created, if it is an enchantment from a spell,
   * add a flag indicating the level of the spell.
   * @param {ActiveEffect5e} effect           The effect that will be created.
   * @param {object} data                     The initial data object provided to the request.
   * @param {DatabaseCreateOperation} options Additional options which modify the creation request.
   */
  static _enchantmentSpellLevel(effect, data, options) {
    if (!effect.isAppliedEnchantment) return;
    const msg = game.messages.get(options.chatMessageOrigin);
    const lvl = msg.flags?.dnd5e?.use?.spellLevel;
    if (!lvl) return;
    let spellLevel;
    if (lvl === 0) spellLevel = 0;
    else spellLevel = parseInt(lvl) || null;
    const flags = effect.flags.dnd5e;
    const newFlags = foundry.utils.mergeObject(flags, { "spellLevel": spellLevel });
    effect.updateSource({ "flags.dnd5e": newFlags });
  }

  /**
   * Check targets for ownership when determining which target selection mode to use.
   * @param {Array} targets  Array of objects with target data, including UUID.
   * @returns {boolean}
   */
  static ownershipCheck(targets) {
    if (!targets) return false;
    for (const target of targets) {
      const actor = fromUuidSync(target.uuid);
      if (actor?.isOwner) return true;
      else continue;
    }    return false;
  }

  /**
   * Sort tokens into owned and unowned categories.
   * @param {Set|Token[]} targets The set or array of tokens to be sorted.
   * @returns {Array}             An Array of length two whose elements are the partitioned pieces of the original
   */
  static partitionTargets(targets) {
    const result = targets.reduce((acc, t) => {
      if (t.isOwner) acc[0].push(t);
      else acc[1].push(t.document.uuid);
      return acc;
    }, [[], []]);
    return result;
  }
}

// <copyright file="effective-socket.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>


/* -------------------------------------------- */
/*  Socket Handling                             */
/* -------------------------------------------- */

class EffectiveSocket {

  /**
   * Register the socket
   * @param {object} request The information passed via socket to be handled by the GM client.
   */
  static init() {
    game.socket.on(SOCKET_ID, (request) => {
      switch (request.type) {
        case "effect":
          EffectiveSocket._effectSocket(request);
          break;
        case "damage":
          EffectiveSocket._damageSocket(request);
      }    });
  }

  /**
   * Make the GM client apply effects to the requested targets.
   * @param {object} request The information passed via socket to be handled by the GM client.
   */
  static async _effectSocket(request) {
    if (game.user !== game.users.activeGM) return;
    const targets = request.data.targets;
    const source = request.data.source;
    const effect = foundry.utils.getType(source) === "string" ? await fromUuid(source) : source;
    const c = fromUuidSync(request.data.caster);
    const concentration = c?.effects?.get(request.data.con);
    const effectData = request.data.effectData;
    const actors = new Set();
    for (const target of targets) {
      const trg = fromUuidSync(target);
      const targetActor = trg.actor ?? trg;
      if (target) actors.add(targetActor);
    }    for (const actor of actors) {
      await EffectiveTray.applyEffectToActor(effect, actor, { effectData, concentration });
    }  }

  /**
   * Make the GM client apply damage to the requested targets
   * @param {object} request The information passed via socket to be handled by the GM client.
   */
  static async _damageSocket(request) {
    if (game.user !== game.users.activeGM) return;
    const id = request.data.id;
    const opts = request.data.opts;

    // Convert damage properties back into a Set for damage application
    const damage = [];
    request.data.damage.forEach(d => {
      foundry.utils.mergeObject(d, { properties: new Set(d.properties) });
      damage.push(d);
    });
    if (opts?.downgrade) foundry.utils.mergeObject(opts, { downgrade: new Set(opts.downgrade) });
    if (opts?.ignore?.immunity) foundry.utils.mergeObject(opts, { "ignore.immunity": new Set(opts.ignore.immunity) });
    if (opts?.ignore?.resistance) foundry.utils.mergeObject(opts, { "ignore.resistance": new Set(opts.ignore.resistance) });
    if (opts?.ignore?.vulnerability) foundry.utils.mergeObject(opts, { "ignore.vulnerability": new Set(opts.ignore.vulnerability) });
    if (opts?.ignore?.modification) foundry.utils.mergeObject(opts, { "ignore.modification": new Set(opts.ignore.modification) });
    return await EffectiveTray.applyTargetDamage(id, opts, damage);
  }
}

// <copyright file="api.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>


class API {

  static init() {
    globalThis.effectiv = {
      applyEffect: API.applyEffect,
      applyDamage: API.applyDamage,
      partitionTargets: EffectiveTray.partitionTargets,
      scroll: EffectiveTray._scroll,
      abstract: {
        elements: {
          effectiveEffectApplication: EffectiveEffectApplication,
          effectiveDamageApplication: EffectiveDamageApplication
        },
        utils: {
          effectiveTray: EffectiveTray,
          effectiveSocket: EffectiveSocket
        }
      }
    };
  }

  /* -------------------------------------------- */
  /*  Effect Application Helper                   */
  /* -------------------------------------------- */

  /**
   * Helper function to allow for macros or other applications to apply effects to owned and unowned targets.
   * @param {string|object|ActiveEffect5e} effect            The effect to apply.
   * @param {Set<Token5e>|Token5e[]|string[]|string} targets Targeted tokens.
   * @param {object} [options]
   * @param {object} [options.effectData]                    A generic data object, which typically handles the level the originating spell was cast at, 
   *                                                         if it originated from a spell, if any. Use flags like { "flags.dnd5e.spellLevel": 1 }.
   * @param {string} [options.concentration]                 The ID (not Uuid) of the concentration effect this effect is dependent on, if any.
   * @param {string|Actor5e} [options.caster]                The Uuid or Actor5e document of the actor that cast the spell that requires concentration, if any.
   */
  static async applyEffect(effect, targets, {effectData = null, concentration = null, caster = null} = {}) {

    // Effect handling
    let toApply;
    const effectType = foundry.utils.getType(effect);
    if (effect instanceof ActiveEffect) {
      toApply = effect.uuid;
    }  
    else if (effectType === "string") {
      toApply = effect;
      effect = await fromUuid(effect);
    } 
    else if (effectType === "Object") {
      toApply = effect;
    }

    // Target handling

    // Handle `game.user.targets`
    let owned;
    let toTarget;
    if (targets instanceof Set) {
      [owned, toTarget] = EffectiveTray.partitionTargets(Array.from(targets));
    }

    // Handle a single Uuid
    else if (foundry.utils.getType(targets) === "string") {
      const t = await fromUuid(targets);
      t.isOwner ? owned = [t] : toTarget = [t.uuid];
    }

    // Handle an array of Tokens
    else if (targets.at(0) instanceof Token) {
      [owned, toTarget] = EffectiveTray.partitionTargets(targets);
    } 
    else {

      // Handle an array of Uuids
      owned = [];
      toTarget = [];
      for (const target of targets) {
        const t = await fromUuid(target);
        if (t.isOwned) owned.push(t);
        else toTarget.push(target);
      }    }  

    // Caster handling
    let spellCaster;
    if (caster instanceof Actor) spellCaster = caster?.uuid;
    else if (foundry.utils.getType(caster) === "string") spellCaster = caster;


    // Apply what effects you can apply yourself
    if (!foundry.utils.isEmpty(owned)) {
      const actors = new Set();
      for (const token of owned) if (token.actor ?? token) actors.add(token.actor ?? token);
      for (const actor of actors) await EffectiveTray.applyEffectToActor(actor, effect, { effectData, concentration });//_applyEffects(actor, effect, {effectData, concentration});
    }
    // Ask the GM client to apply the rest
    if (foundry.utils.isEmpty(toTarget)) return;
    if (!game.users.activeGM) return ui.notifications.warn(game.i18n.localize("EFFECTIVETRAY.NOTIFICATION.NoActiveGMEffect"));

    await game.socket.emit(SOCKET_ID, { 
      type: "effect",
      data: { 
        source: toApply,
        targets: toTarget,
        effectData: effectData,
        con: concentration,
        caster: spellCaster
      }
    });
  }

  /* -------------------------------------------- */
  /*  Damage Application Helper                   */
  /*    see README and the system's damage        */
  /*    application method for documentation      */
  /* -------------------------------------------- */

  static async applyDamage(damage = [], opts = {}, id) {
    if (!game.users.activeGM) return ui.notifications.warn(game.i18n.localize("EFFECTIVETRAY.NOTIFICATION.NoActiveGMDamage"));
    await game.socket.emit(SOCKET_ID, { type: "damage", data: { id, opts, damage } });
  }
}

// <copyright file="setup.mjs" company="alterNERDtive">
// Copyright 2025 alterNERDtive.
//
// This file is part of the Effective Tray NG Foundry module.
//
// The Effective Tray NG Foundry module is free software: you can distribute
// it and/or modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of the License,
// or (at your option) any later version.
//
// The EffectiveTray NG Foundry module is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with
// the EffectiveTray NG Foundry module.  If not, see
// &lt;https://www.gnu.org/licenses/&gt;.
// </copyright>


Hooks.once("init", EffectiveSocket.init);
Hooks.once("init", ModuleSettings.init);
Hooks.once("init", EffectiveTray.init);
Hooks.once("init", API.init);
